// Database of common foods (Fiber per 100g)
const FOOD_DATABASE = [
    { name: 'Овсянка (хлопья)', fiber: 10.1 },
    { name: 'Яблоко', fiber: 2.4 },
    { name: 'Банан', fiber: 2.6 },
    { name: 'Морковь', fiber: 2.8 },
    { name: 'Брокколи', fiber: 2.6 },
    { name: 'Чечевица (вареная)', fiber: 7.9 },
    { name: 'Миндаль', fiber: 12.5 },
    { name: 'Чернослив', fiber: 7.1 },
    { name: 'Авокадо', fiber: 6.7 },
    { name: 'Чиа (семена)', fiber: 34.4 },
    { name: 'Малина', fiber: 6.5 },
    { name: 'Груша', fiber: 3.1 },
    { name: 'Цельнозерновой хлеб', fiber: 7.0 },
    { name: 'Гречка', fiber: 10.0 },
    { name: 'Кукуруза', fiber: 2.7 },
    { name: 'Фасоль красная', fiber: 6.4 },
    { name: 'Киви', fiber: 3.0 },
    { name: 'Клубника', fiber: 2.0 },
    { name: 'Орехи грецкие', fiber: 6.7 },
];

const FACTS = [
    "Клетчатка — это 'метла' для вашего кишечника. Она очищает его от токсинов.",
    "Суточная взрослая норма клетчатки составляет 25–35 грамм.",
    "Клетчатка замедляет всасывание сахара, помогая избежать резких скачков глюкозы.",
    "Продукты с высоким содержанием волокон помогают дольше чувствовать сытость.",
    "В кожуре яблок и огурцов содержится больше клетчатки, чем в их мякоти.",
    "Употребление достаточного количества клетчатки снижает риск сердечно-сосудистых заболеваний.",
    "Клетчатка кормит полезные бактерии в вашем микробиоме."
];

// State Manager
const state = {
    goal: parseInt(localStorage.getItem('fiber_goal')) || 25,
    history: JSON.parse(localStorage.getItem('fiber_history')) || [], // Items for TODAY
    currentDate: new Date().toDateString()
};

// DOM Elements
const elements = {
    screens: document.querySelectorAll('.screen'),
    navItems: document.querySelectorAll('.nav-item[data-screen]'),
    progressCircle: document.getElementById('progressCircle'),
    currentFiber: document.getElementById('currentFiber'),
    goalFiber: document.getElementById('goalFiber'),
    remainingFiber: document.getElementById('remainingFiber'),
    percentComplete: document.getElementById('percentComplete'),
    logList: document.getElementById('logList'),
    foodSearch: document.getElementById('foodSearch'),
    searchResults: document.getElementById('searchResults'),
    manualEntry: document.getElementById('manualEntry'),
    qtyModal: document.getElementById('qtyModal'),
    modalFoodName: document.getElementById('modalFoodName'),
    modalFoodFiber: document.getElementById('modalFoodFiber'),
    qtyInput: document.getElementById('qtyInput'),
    confirmQty: document.getElementById('confirmQty'),
    cancelQty: document.getElementById('cancelQty'),
    addBtn: document.getElementById('addBtn'),
    backBtn: document.getElementById('backBtn'),
    factDisplay: document.getElementById('factDisplay'),
    goalInput: document.getElementById('goalInput'),
    saveSettingsBtn: document.getElementById('saveSettingsBtn'),
    settingsBtn: document.getElementById('settingsBtn'),
    closeSettingsBtn: document.getElementById('closeSettingsBtn'),
    searchInternetBtn: document.getElementById('searchInternetBtn')
};

let selectedProduct = null;

// Initialize
function init() {
    checkDay();
    updateUI();
    showRandomFact();
    setupEventListeners();
}

function checkDay() {
    const savedDate = localStorage.getItem('last_date');
    if (savedDate !== state.currentDate) {
        // New day! Clear history (or archive it if we had a full persistence model)
        state.history = [];
        localStorage.setItem('fiber_history', JSON.stringify([]));
        localStorage.setItem('last_date', state.currentDate);
    }
}

function setupEventListeners() {
    // Navigation
    elements.navItems.forEach(item => {
        item.addEventListener('click', () => {
            const screenId = item.getAttribute('data-screen');
            switchScreen(screenId);
        });
    });

    elements.addBtn.addEventListener('click', () => switchScreen('logScreen'));
    elements.backBtn.addEventListener('click', () => switchScreen('home'));

    elements.settingsBtn.addEventListener('click', () => {
        elements.goalInput.value = state.goal;
        switchScreen('settingsScreen');
    });

    elements.closeSettingsBtn.addEventListener('click', () => switchScreen('home'));

    // Search
    elements.foodSearch.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase().trim();
        renderSearchResults(query);
    });

    // Quantity Modal
    elements.cancelQty.addEventListener('click', () => elements.qtyModal.classList.remove('active'));
    elements.confirmQty.addEventListener('click', () => {
        if (!selectedProduct) return;
        const qty = parseFloat(elements.qtyInput.value) || 100;
        const fiberAmount = (selectedProduct.fiber * qty) / 100;

        addEntry(selectedProduct.name, qty, fiberAmount);
        elements.qtyModal.classList.remove('active');
        switchScreen('home');
        elements.foodSearch.value = '';
    });

    // Save Settings
    elements.saveSettingsBtn.addEventListener('click', () => {
        const val = parseInt(elements.goalInput.value);
        if (val > 0) {
            state.goal = val;
            localStorage.setItem('fiber_goal', val);
            updateUI();
            switchScreen('home');
        }
    });

    // Internet Search using OpenFoodFacts
    elements.searchInternetBtn.addEventListener('click', async () => {
        const query = elements.foodSearch.value;
        if (!query) return;

        elements.searchInternetBtn.textContent = 'Ищем в сети...';
        elements.searchInternetBtn.disabled = true;

        try {
            const response = await fetch(`https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(query)}&search_simple=1&action=process&json=1&page_size=5`);
            const data = await response.json();

            if (data.products && data.products.length > 0) {
                const productWithFiber = data.products.find(p => p.nutriments && p.nutriments.fiber_100g);

                if (productWithFiber) {
                    const fiberValue = parseFloat(productWithFiber.nutriments.fiber_100g);
                    const name = productWithFiber.product_name || query;
                    showQtyModal({ name, fiber: fiberValue });
                } else {
                    alert("Данные о клетчатке не найдены. Попробуйте другой продукт.");
                }
            } else {
                alert("Продукт не найден в сети.");
            }
        } catch (error) {
            console.error("Search error:", error);
            alert("Ошибка при поиске.");
        } finally {
            elements.searchInternetBtn.textContent = 'Найти в интернете';
            elements.searchInternetBtn.disabled = false;
        }
    });
}

function switchScreen(id) {
    elements.screens.forEach(s => s.classList.remove('active'));
    const target = document.getElementById(id);
    if (target) {
        target.classList.add('active');
        // Update nav icons
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        const navItem = document.querySelector(`.nav-item[data-screen="${id}"]`);
        if (navItem) navItem.classList.add('active');
    }
}

function renderSearchResults(query) {
    if (!query) {
        elements.searchResults.innerHTML = '';
        elements.manualEntry.classList.add('hidden');
        return;
    }

    const matches = FOOD_DATABASE.filter(f => f.name.toLowerCase().includes(query));

    elements.searchResults.innerHTML = matches.map(f => `
        <div class="result-item" data-name="${f.name}">
            <span>${f.name}</span>
            <small>${f.fiber}г / 100г</small>
        </div>
    `).join('');

    // Add listeners to results
    document.querySelectorAll('.result-item').forEach(item => {
        item.addEventListener('click', () => {
            const name = item.getAttribute('data-name');
            const product = FOOD_DATABASE.find(f => f.name === name);
            showQtyModal(product);
        });
    });

    if (matches.length === 0) {
        elements.manualEntry.classList.remove('hidden');
    } else {
        elements.manualEntry.classList.add('hidden');
    }
}

function showQtyModal(product) {
    selectedProduct = product;
    elements.modalFoodName.textContent = product.name;
    elements.modalFoodFiber.textContent = `${product.fiber}г клетчатки на 100г`;
    elements.qtyInput.value = 100;
    elements.qtyModal.classList.add('active');
}

function addEntry(name, qty, fiber) {
    const entry = {
        id: Date.now(),
        name,
        qty,
        fiber: parseFloat(fiber.toFixed(1)),
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    state.history.unshift(entry);
    localStorage.setItem('fiber_history', JSON.stringify(state.history));
    updateUI();
}

function updateUI() {
    const total = state.history.reduce((sum, item) => sum + item.fiber, 0);
    const goal = state.goal;

    // Progress Ring
    const radius = 45;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (Math.min(total / goal, 1) * circumference);
    elements.progressCircle.style.strokeDasharray = `${circumference} ${circumference}`;
    elements.progressCircle.style.strokeDashoffset = offset;

    // Stats
    elements.currentFiber.textContent = total.toFixed(1);
    elements.goalFiber.textContent = goal;
    elements.remainingFiber.textContent = (Math.max(goal - total, 0)).toFixed(1) + 'г';
    elements.percentComplete.textContent = Math.round((total / goal) * 100) + '%';

    // Log List
    if (state.history.length === 0) {
        elements.logList.innerHTML = '<div class="empty-state">Пока ничего не добавлено</div>';
    } else {
        elements.logList.innerHTML = state.history.map(item => `
            <div class="log-item">
                <div class="info">
                    <h4>${item.name}</h4>
                    <p>${item.qty}г • ${item.time}</p>
                </div>
                <div class="log-actions">
                    <span class="amount">+${item.fiber}г</span>
                    <button class="delete-btn" onclick="window.removeEntry(${item.id})">✕</button>
                </div>
            </div>
        `).join('');
    }
}

// Export to window for onclick
window.removeEntry = (id) => {
    state.history = state.history.filter(item => item.id !== id);
    localStorage.setItem('fiber_history', JSON.stringify(state.history));
    updateUI();
};

function showRandomFact() {
    const fact = FACTS[Math.floor(Math.random() * FACTS.length)];
    elements.factDisplay.innerHTML = `<p>${fact}</p>`;
}

init();
